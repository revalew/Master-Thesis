# xpt2046_circuitpython docs

## import
```py
import xpt2046_circuitpython
# .Touch, .ReadFailedException
```

## classes
### [xpt2046_circuitpython.Touch](xpt2046_circuitpython.md#Touch)
### [xpt2046_circuitpython.ReadFailedException](xpt2046_circuitpython.md#ReadFailedException)