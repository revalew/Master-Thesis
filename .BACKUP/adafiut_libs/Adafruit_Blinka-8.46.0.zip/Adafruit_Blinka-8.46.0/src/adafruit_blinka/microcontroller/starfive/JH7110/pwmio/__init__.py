# SPDX-FileCopyrightText: 2024 Vladimir Shtarev, Jetbrains Research
#
# SPDX-License-Identifier: MIT
"""Custom PWMOut Wrapper for VisionFive.GPIO PWM Class"""
